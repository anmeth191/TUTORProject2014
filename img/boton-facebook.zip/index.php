<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Como hacer un boton de Facebook con Javascript, PHP y Mysql</title>

<script type="text/javascript">
function showService(e){if(e==""){document.getElementById("txtHint").innerHTML="";return}if(window.XMLHttpRequest){xmlhttp=new XMLHttpRequest}else{xmlhttp=new ActiveXObject("Microsoft.XMLHTTP")}xmlhttp.onreadystatechange=function(){if(xmlhttp.readyState==4&&xmlhttp.status==200){document.getElementById("txtHint").innerHTML=xmlhttp.responseText}};xmlhttp.open("GET","procesa.php?id="+e,true);xmlhttp.send()}</script>

<style>
body{ font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif}
.boton, .exito{ height:16px; background-image:url(f.png); padding-top:4px; background-repeat:no-repeat; padding-left:26px; background-position:7% 50%; font-size:11px; font-weight:bold; width:57px; background-color:#4F62AA; border-radius:3px; color:#FFF; font-family:Gotham, "Helvetica Neue", Helvetica, Arial, sans-serif; display:inline-block}

.exito{ background-image:url(exito.png);}
</style>
</head>

<body>
<div id="txtHint">
<a onclick="showService(1)" href="#" style="text-decoration:none; color:#FFF"><div class="boton">Me gusta</div></a>
</div>
</body>
</html>
