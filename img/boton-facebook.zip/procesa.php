<?php 
if($_COOKIE['megusta'] != "si"){
setcookie("megusta", "si", time()+172800,"/");
echo'<div id="txtHint">
<a onclick="showService(1)" href="#" style="text-decoration:none; color:#FFF"><div class="exito">Me gusta</div></a> Te gusta esto';
}else{
	
	setcookie("megusta", "no", time()+172800,"/");
echo'<div id="txtHint">
<a onclick="showService(1)" href="#" style="text-decoration:none; color:#FFF"><div class="boton">Me gusta</div></a>';
	
	}
?>